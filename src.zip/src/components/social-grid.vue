<template>
    <div class="row icon-grid justify-content-md-center">
        <ul class="list-inline dev-icons">
          <li class="list-inline-item">
            <a href="https://github.com/jaimin-p" target="_blank" class="text-secondary">
                <i class="fab fa-github hvr-bob"></i>
              <div class="small">Github</div>
            </a>
          </li>
          <li class="list-inline-item">
            <a href="https://www.linkedin.com/in/jaiminece" target="_blank" style="color:#04669A">
             <i class="fab fa-linkedin hvr-bob"></i>
              <div class="small">LinkenIn</div>
            </a>
          </li>
          <li class="list-inline-item">
            <a href="https://www.freecodecamp.org/jaimin" target="_blank" style="color:green">
            <i class="fab fa-free-code-camp hvr-bob"></i>
              <div class="small">FreeCodeCamp</div>
            </a>
          </li>
          <li class="list-inline-item">
            <a href="https://codepen.io/jaiminp" target="_blank" class="text-dark"> 
              <i class="fab fa-codepen hvr-bob"></i>
              <div class="small">CodePen</div>
            </a>
          </li>
        </ul>
      </div>
</template>

<script>
export default {
    
}
</script>


<style scoped>

@import 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css';
@import 'https://cdn.rawgit.com/konpa/devicon/df6431e323547add1b4cf45992913f15286456d3/devicon.min.css';
@import 'https://use.fontawesome.com/releases/v5.3.1/css/all.css';

 .small
 {
  font-size: 0.8rem !important; 
 }
 .dev-icons {
  font-size: 3rem;
  margin :  0 auto;
}
.list-inline {
    padding-left: 0;
    list-style: none;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 1rem;
}

/* Hover.css from github*/
/* Bob */
@-webkit-keyframes hvr-bob {
  0% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
  50% {
    -webkit-transform: translateY(-4px);
    transform: translateY(-4px);
  }
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@keyframes hvr-bob {
  0% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
  50% {
    -webkit-transform: translateY(-4px);
    transform: translateY(-4px);
  }
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@-webkit-keyframes hvr-bob-float {
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@keyframes hvr-bob-float {
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
.hvr-bob {
  display: inline-block;
  vertical-align: middle;
  -webkit-transform: perspective(1px) translateZ(0);
  transform: perspective(1px) translateZ(0);
  box-shadow: 0 0 1px rgba(0, 0, 0, 0);
}
.hvr-bob:hover, .hvr-bob:focus, .hvr-bob:active {
  -webkit-animation-name: hvr-bob-float, hvr-bob;
  animation-name: hvr-bob-float, hvr-bob;
  -webkit-animation-duration: .3s, 1.5s;
  animation-duration: .3s, 1.5s;
  -webkit-animation-delay: 0s, .3s;
  animation-delay: 0s, .3s;
  -webkit-animation-timing-function: ease-out, ease-in-out;
  animation-timing-function: ease-out, ease-in-out;
  -webkit-animation-iteration-count: 1, infinite;
  animation-iteration-count: 1, infinite;
  -webkit-animation-fill-mode: forwards;
  animation-fill-mode: forwards;
  -webkit-animation-direction: normal, alternate;
  animation-direction: normal, alternate;
}
</style>