<template>
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg- rounded">
      <!-- <a class="navbar-brand" href="#">
        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#resumePopup">
        Resume</button></a> -->

      <div
        class="modal fade"
        id="resumePopup"
        tabindex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-body">
              Thank You For Your Valuable Time !!
            </div>
            <div class="modal-footer">
              <button
                type="button"
                data-dismiss="modal"
                class="btn btn-outline-danger"
              >
                Close
              </button>
              <a
                href="mailto:jaimin.ece@gmail.com"
                target="_blank"
                class="btn btn-outline-success"
                >Email</a
              >
            </div>
          </div>
        </div>
      </div>

      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav nav-tabs ml-auto">
          <li class="nav-item">
            <router-link class="nav-link" to="/"
              ><vue-fontawesome
                icon="home"
                class="pr-auto"
                color="grey"
              ></vue-fontawesome>
              Home</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/skills"
              ><vue-fontawesome
                icon="code"
                class="pr-auto"
                color="grey"
              ></vue-fontawesome>
              Skills</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/projects"
              ><vue-fontawesome
                icon="briefcase"
                class="pr-auto"
                color="grey"
              ></vue-fontawesome>
              Projects</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/Certification"
              ><vue-fontawesome
                icon="certificate"
                class="pr-auto"
                color="grey"
              ></vue-fontawesome>
              Certification</router-link
            >
          </li>

          <li class="nav-item">
            <router-link class="nav-link" to="/About"
              ><vue-fontawesome
                icon="info-circle"
                class="pr-auto"
                color="grey"
              ></vue-fontawesome>
              About</router-link
            >
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<script>
export default {
  name: "Navbar"
};
</script>

<style scoped>
#skills-tab:hover {
  color: blue;
}

#portfolio-tab:hover {
  color: lightcoral;
}

#cert-tab:hover {
  color: green;
}</style
>>
