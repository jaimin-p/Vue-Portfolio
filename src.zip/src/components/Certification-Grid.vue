<template>
  <div class="card text-center m-5">
    <div class="">
      <img
        id="image-certification"
        :src="Certification.img"
        :alt="Certification.name"
      />
    </div>
    <div class="card-body">
      <a
        :href="Certification.link"
        target="_blank"
        class="btn btn-outline-primary"
        >Certificate</a
      >
    </div>
    <div class="card-footer text-muted">
      Issued on {{ Certification.issued }}
    </div>
  </div>
</template>

<script>
export default {
  props: {
    Certification: Object
  }
};
</script>

<style scoped>
#image-certification {
  margin-top: 10px;
  max-height: 200px;
}
</style>
