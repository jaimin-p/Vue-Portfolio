<template>
  <div class="card shadow">
    <div class="card-header small text-center font-weight-bold">
      {{ Project.display }}
    </div>
    <a :href="Project.link" target="_blank">
      <img
        class="card-img-top img-fluid image-cap"
        :src="Project.img"
        alt="Card image cap"
      />
    </a>

    <div class="card-footer text-center text-muted">
      <span
        class="badge badge-pill badge-secondary"
        style="margin-left:5px;font-size:0.68rem"
        v-for="technology in Project.Technologies"
        :key="technology"
        >{{ technology }}</span
      >
    </div>
  </div>
</template>

<script>
export default {
  props: {
    Project: Object
  }
};
</script>

<style scoped>
.image-cap {
  height: 180px;
}
.row:hover .card {
  box-shadow: none;
}
.row:hover .card:hover {
  border: 1px solid grey;
}
</style>
