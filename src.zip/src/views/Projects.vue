<template>
  <div class="container">
    <div class="row">
      <div
        class="col-md-6 col-lg-6 col-xl-3 py-2"
        v-for="Project in Projects"
        :key="Project.id"
      >
        <ProjectGrid :Project="Project"></ProjectGrid>
      </div>
    </div>
  </div>
</template>

<script>
import ProjectGrid from "@/components/Project-Grid.vue";
import { mapState } from "vuex";

export default {
  components: {
    ProjectGrid
  },

  computed: mapState({
    Projects: state => state.info.Projects
  })
};
</script>
