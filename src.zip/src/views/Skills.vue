<template>
  <div class="container mt-2">
    <div class="text-muted">

      <div class="row align-items-center justify-content-center">
        <div class="col-8 text-center shadow">
          <h4 class="text-muted">Microsoft Technologies</h4>
          <hr />
          <ul class="list-inline dev-icons">
            <li class="list-inline-item">
              <i class="devicon-csharp-plain colored hvr-bob"></i>
              <div class="small">C#</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-dot-net-plain colored   hvr-bob"></i>
              <div class="small">ASP.NET</div>
            </li>
            <li class="list-inline-item">
              <i class="fas fa-database hvr-bob"></i>
              <div class="small">SQL Server</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-visualstudio-plain colored hvr-bob"></i>
              <div class="small">Visual Studio</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-amazonwebservices-original hvr-bob"></i>
              <div class="small">Azure Cloud</div>
            </li>
          </ul>
        </div>
      </div>
      

      <div class="row align-items-center  mt-3 justify-content-center">
        <div class="col-8 text-center shadow">
          <ul class="list-inline dev-icons">
            <h4 class="text-muted">Responsive Web Design</h4>
            <hr />
            <li class="list-inline-item">
              <i class="devicon-html5-plain colored hvr-bob"></i>
              <div class="small">HTML5</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-css3-plain colored hvr-bob"></i>
              <div class="small">CSS3</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-bootstrap-plain colored hvr-bob"></i>
              <div class="small">Bootstrap</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-javascript-plain colored hvr-bob"></i>
              <div class="small">JavaScript</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-jquery-plain colored hvr-bob"></i>
              <div class="small">jQuery</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-vuejs-plain colored  hvr-bob"></i>
              <div class="small">VueJS</div>
            </li>

            <li class="list-inline-item">
              <i class="fab fa-npm hvr-bob"></i>
              <div class="small">NPM</div>
            </li>
          </ul>
        </div>
      </div>

      <div class="row align-items-center mt-3 justify-content-center">
        <div class="col-8 text-center shadow">
          <h4 class="text-muted">Version Control</h4>
          <hr />
          <ul class="list-inline dev-icons">
            <li class="list-inline-item">
              <i class="devicon-git-plain colored   hvr-bob"></i>
              <div class="small">git</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-github-plain colored   hvr-bob"></i>
              <div class="small">Github</div>
            </li>
            <li class="list-inline-item">
              <i class="devicon-visualstudio-plain colored   hvr-bob"></i>
              <div class="small">TFS</div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.dev-icons {
  font-size: 3rem;
  margin: 0 auto;
}

dl,
ol,
ul {
  margin-top: 0;
  margin-bottom: 1rem;
}

.list-inline {
  padding-left: 0;
  list-style: none;
}

.small {
  font-size: 0.8rem !important;
}


/* Hover.css from github*/
/* Bob */
@-webkit-keyframes hvr-bob {
  0% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
  50% {
    -webkit-transform: translateY(-4px);
    transform: translateY(-4px);
  }
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@keyframes hvr-bob {
  0% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
  50% {
    -webkit-transform: translateY(-4px);
    transform: translateY(-4px);
  }
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@-webkit-keyframes hvr-bob-float {
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
@keyframes hvr-bob-float {
  100% {
    -webkit-transform: translateY(-8px);
    transform: translateY(-8px);
  }
}
.hvr-bob {
  display: inline-block;
  vertical-align: middle;
  -webkit-transform: perspective(1px) translateZ(0);
  transform: perspective(1px) translateZ(0);
  box-shadow: 0 0 1px rgba(0, 0, 0, 0);
}
.hvr-bob:hover, .hvr-bob:focus, .hvr-bob:active {
  -webkit-animation-name: hvr-bob-float, hvr-bob;
  animation-name: hvr-bob-float, hvr-bob;
  -webkit-animation-duration: .3s, 1.5s;
  animation-duration: .3s, 1.5s;
  -webkit-animation-delay: 0s, .3s;
  animation-delay: 0s, .3s;
  -webkit-animation-timing-function: ease-out, ease-in-out;
  animation-timing-function: ease-out, ease-in-out;
  -webkit-animation-iteration-count: 1, infinite;
  animation-iteration-count: 1, infinite;
  -webkit-animation-fill-mode: forwards;
  animation-fill-mode: forwards;
  -webkit-animation-direction: normal, alternate;
  animation-direction: normal, alternate;
}
</style>
