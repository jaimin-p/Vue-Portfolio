<template>
  <div class="container text-center" id="home">
    <img
      class="shadow-lg"
      id="profile-photo"
      src="https://jaimin-p.github.io/img/profile-photo.jpg"
      alt="Profile-Photo"
    />

    <h4 class="mt-4">{{ title }}</h4>
    <h5 class="text-muted">
      An Experienced IT Professional in leveraging .NET Application through full
      lifecycle.
    </h5>
    <h5 class="text-muted">Built modern applications with</h5>
    <h5 class="text-muted">
      <span class="badge badge-primary">C#.NET</span>
      <span class="badge badge-danger ml-2">ASP.NET MVC</span>
      <span class="badge badge-success ml-2">VueJS</span>
      <span class="badge badge-dark ml-2"> MICROSOFT SQL SERVER</span>
    </h5>
    <hr />
    <SocialGrid></SocialGrid>
  </div>
</template>

<script>
import SocialGrid from "@/components/social-grid.vue";

export default {
  name: "home",
  data: function() {
    return {
      title: "Hello I am Jaimin"
    };
  },
  components: {
    SocialGrid
  }
};
</script>

<style scoped>
#profile-photo {
  margin-top: 40px;
  max-width: 250px;
  max-height: 300px;
  border-radius: 50%;
}</style
>>
