<template>
  <div class="container">
    <div class="row mt-4">
      <CertificateGrid
        v-for="Certification in Certifications"
        :Certification="Certification"
        :key="Certification.id"
      />
    </div>
  </div>
</template>

<script>
import CertificateGrid from "@/components/Certification-Grid.vue";
import { mapState } from "vuex";

export default {
  components: {
    CertificateGrid
  },

  computed: mapState({
    Certifications: state => state.info.Certifications
  })
};
</script>
