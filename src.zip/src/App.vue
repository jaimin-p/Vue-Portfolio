<template>
  <div id="home">
    <div id="nav">
      <NavBar />
    </div>
    <router-view />
  </div>
</template>

<script>
import NavBar from "./components/Nav.vue";

export default {
  name: "home",
  components: {
    NavBar
  },
  async mounted() {
    this.$store.dispatch("fetchInfo");
  }
};
</script>

<style>
#app {
  font-family: Segoe UI, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
