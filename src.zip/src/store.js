import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";
import VueAxios from "vue-axios";

Vue.use(Vuex);
Vue.use(VueAxios, axios);

export default new Vuex.Store({
  state: {
    info: String,
    loading: true,
    errored: false
  },
  actions: {
    fetchInfo({ commit }) {
      axios
        .get("https://vue-portfolio-b49b1.firebaseio.com/info.json")
        .then(r => r.data)
        .then(res => {
          commit("SET_INFO", res);
        })
        .catch(error => {
          console.log(error);
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    }
  },
  mutations: {
    SET_INFO(state, res) {
      state.info = res;
    }
  }
});
